
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;

const rooms = {};

io.on('connection', (socket) => {
  let currentRoom = null;
  let nickname = 'Anon_' + Math.floor(Math.random() * 10000);

  socket.on('joinRoom', (roomName) => {
    currentRoom = roomName;
    socket.join(currentRoom);
    if (!rooms[currentRoom]) rooms[currentRoom] = {};
    rooms[currentRoom][socket.id] = nickname;

    io.to(currentRoom).emit('message', `${nickname} se ha unido a la sala.`);
  });

  socket.on('message', (msg) => {
    if (currentRoom) {
      const name = rooms[currentRoom][socket.id];
      io.to(currentRoom).emit('message', `${name}: ${msg}`);
    }
  });

  socket.on('disconnect', () => {
    if (currentRoom && rooms[currentRoom]) {
      io.to(currentRoom).emit('message', `${nickname} ha salido de la sala.`);
      delete rooms[currentRoom][socket.id];
      if (Object.keys(rooms[currentRoom]).length === 0) delete rooms[currentRoom];
    }
  });
});

app.use(express.static('public'));

server.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
